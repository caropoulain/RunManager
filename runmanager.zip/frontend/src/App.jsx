import React from 'react'
import Upload from './components/Upload'

export default function App(){
  return (
    <div>
      <h1>RunManager</h1>
      <Upload />
    </div>
  )
}